# Department & Employee JasperReport (with Subreport)

A complete JasperReports project that demonstrates:
- **Main report** iterating over Departments
- **Subreport** embedded per-department showing its Employees
- **JSON datasource** — no database required
- **PDF export**

---

## 📁 Project Structure

```
jasper-report/
├── pom.xml                                   ← Maven build file
├── data/
│   └── departments.json                      ← JSON datasource
└── src/
    └── main/
        ├── java/com/example/
        │   └── ReportRunner.java             ← Main Java runner
        └── resources/reports/
            ├── DepartmentReport.jrxml        ← Main report design
            └── EmployeeSubreport.jrxml       ← Subreport design
```

---

## ⚙️ Prerequisites

| Tool | Version |
|------|---------|
| Java | 11 or higher |
| Maven | 3.6+ |

---

## 🚀 How to Run

### 1. Build the project

```bash
cd jasper-report
mvn clean package
```

This will:
- Compile the `.jrxml` report designs → `.jasper` files
- Package all dependencies into a fat JAR

### 2. Run the report

```bash
java -jar target/jasper-report-1.0.0-jar-with-dependencies.jar
```

The PDF is saved to `output/DepartmentReport.pdf`.

You can also specify a custom output path:

```bash
java -jar target/jasper-report-1.0.0-jar-with-dependencies.jar /path/to/MyReport.pdf
```

---

## 📊 Data Format (JSON)

The report reads from `data/departments.json`. Structure:

```json
{
  "departments": [
    {
      "dept_id": "D001",
      "dept_name": "Engineering",
      "location": "Bengaluru",
      "budget": 5000000,
      "employees": [
        { "emp_id": "E001", "name": "...", "role": "...", "salary": 120000, "joined": "2019-03-15" }
      ]
    }
  ]
}
```

Add more departments or employees by editing this file — no code changes needed.

---

## 🔗 How the Subreport Works

In `DepartmentReport.jrxml`, the subreport element uses a `JsonDataSource` expression
to extract employees **matching the current department's ID**:

```xml
<dataSourceExpression>
  <![CDATA[
    new net.sf.jasperreports.engine.data.JsonDataSource(
        new java.io.FileInputStream($P{JSON_DATA_FILE}),
        "departments[dept_id==" + $F{dept_id} + "].employees"
    )
  ]]>
</dataSourceExpression>

<subreportExpression>
  <![CDATA[$P{SUBREPORT_DIR} + "EmployeeSubreport.jasper"]]>
</subreportExpression>
```

The `SUBREPORT_DIR` parameter tells the main report where to find the compiled
`EmployeeSubreport.jasper` file.

---

## 🎨 Report Layout

```
┌────────────────────────────────────────────────────────┐
│         DEPARTMENT & EMPLOYEE REPORT           [title] │
│              Organizational Structure Overview          │
├────────────────────────────────────────────────────────┤
│  ┌─ [Engineering]  ────────  ID: D001 | Bengaluru ─┐  │
│  │  Budget: ₹50,00,000                              │  │
│  │  ┌──────────────────────────────────────────┐   │  │
│  │  │ EMP ID │ NAME          │ ROLE   │ SALARY │   │  │  ← Subreport
│  │  │ E001   │ Ananya Sharma │ Sr Eng │ 1,20,000│  │  │
│  │  │  ...   │  ...          │  ...   │  ...   │   │  │
│  │  │ DEPT TOTALS            │ 4 emp  │ 4,70,000│  │  │
│  │  └──────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌─ [Human Resources] ─ ...                         ┐  │
│  └──────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────┤
│  TOTAL COMBINED BUDGET (ALL DEPARTMENTS): ₹1,03,00,000 │
└────────────────────────────────────────────────────────┘
```

---

## 🔧 Customization

| What to change | Where |
|---|---|
| Add/remove departments or employees | `data/departments.json` |
| Report title, colors, fonts | `DepartmentReport.jrxml` |
| Employee table columns | `EmployeeSubreport.jrxml` |
| Currency symbol | Change `₹` in the `pattern` attributes in both `.jrxml` files |
| Export format (HTML/Excel) | `ReportRunner.java` — swap `JRPdfExporter` |

---

## 📦 Key Dependencies (from pom.xml)

| Artifact | Purpose |
|---|---|
| `jasperreports` | Core engine |
| `jasperreports-json` | JSON datasource |
| `itext 2.1.7` | PDF rendering |
| `slf4j-simple` | Logging |
