package com.example;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JsonDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.*;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Main runner: compiles .jrxml files, binds JSON data, exports to PDF.
 *
 * Usage:
 *   mvn clean package
 *   java -jar target/jasper-report-1.0.0-jar-with-dependencies.jar [output.pdf]
 *
 * Or from an IDE, run main() directly.
 */
public class ReportRunner {

    public static void main(String[] args) throws Exception {

        // ── Paths ──────────────────────────────────────────────────────────
        String reportsDir  = "src/main/resources/reports/";
        String dataFile    = "data/departments.json";
        String outputPdf   = args.length > 0 ? args[0] : "output/DepartmentReport.pdf";

        // Ensure output directory exists
        new File("output").mkdirs();

        System.out.println("=== JasperReports: Department & Employee Report ===");

        // ── Step 1: Compile JRXML → .jasper ───────────────────────────────
        System.out.println("[1/3] Compiling report designs...");

        // Compile subreport first (main report references it)
        JasperReport subreport = JasperCompileManager.compileReport(
                reportsDir + "Subeport_Employeet.jrxml");
        JasperCompileManager.writeReportToFile(
                subreport, reportsDir + "Subeport_Employee.jasper");

        // Compile main report
        JasperReport mainReport = JasperCompileManager.compileReport(
                reportsDir + "MainReport_Department.jrxml");

        // ── Step 2: Fill report with JSON data ─────────────────────────────
        System.out.println("[2/3] Filling report with JSON data from: " + dataFile);

        Map<String, Object> params = new HashMap<>();
        params.put("SUBREPORT_DIR", reportsDir);      // where .jasper files live
        params.put("JSON_DATA_FILE", dataFile);        // passed into subreport expression

        // The main datasource iterates over the "departments" array
        JsonDataSource mainDs = new JsonDataSource(
                new FileInputStream(dataFile), "departments");

        JasperPrint jasperPrint = JasperFillManager.fillReport(mainReport, params, mainDs);

        // ── Step 3: Export to PDF ──────────────────────────────────────────
        System.out.println("[3/3] Exporting PDF to: " + outputPdf);

        JRPdfExporter exporter = new JRPdfExporter();
        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputPdf));

        SimplePdfExporterConfiguration config = new SimplePdfExporterConfiguration();
        config.setMetadataTitle("Department & Employee Report");
        config.setMetadataAuthor("ReportRunner");
        config.setMetadataSubject("Organizational Structure");
        config.setMetadataKeywords("departments, employees, jasperreports");
        exporter.setConfiguration(config);

        exporter.exportReport();

        System.out.println("\n✅  Done! Report saved to: " + outputPdf);
        System.out.println("    Open it with any PDF viewer.");
    }
}
